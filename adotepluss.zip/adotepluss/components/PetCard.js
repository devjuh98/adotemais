import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import theme from '../styles/theme';

export default function PetCard({ name, breed, age, image }) {
  return (
    <View style={styles.card}>
      <Image source={{ uri: image }} style={styles.img} />
      <View style={styles.info}>
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.details}>{breed} • {age}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  img: {
    width: '100%',
    height: 180,
  },
  info: {
    padding: theme.spacing(1.5),
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
    color: theme.colors.text,
  },
  details: {
    color: theme.colors.secondary,
    marginTop: 4,
  },
});
