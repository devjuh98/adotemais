import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import theme from '../styles/theme';

export default function ChatBubble({ message, isSender }) {
  return (
    <View style={[styles.bubble, isSender ? styles.sender : styles.receiver]}>
      <Text style={styles.text}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  bubble: {
    maxWidth: '80%',
    padding: 10,
    borderRadius: 10,
    marginVertical: 4,
  },
  sender: {
    backgroundColor: theme.colors.primary,
    alignSelf: 'flex-end',
  },
  receiver: {
    backgroundColor: '#E5E7EB',
    alignSelf: 'flex-start',
  },
  text: {
    color: 'white',
    fontFamily: theme.fonts.regular,
  },
});
