export default {
  colors: {
    primary: '#6BCB77',
    secondary: '#8A4FFF',
    background: '#F7F8FA',
    text: '#333',
    accent: '#CDB4FF'
  },
  fonts: {
    regular: 'Poppins_400Regular',
    bold: 'Poppins_700Bold',
  },
  spacing: (value) => value * 8,
};
