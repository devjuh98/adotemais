import React from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import theme from '../styles/theme';

export default function SearchScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Buscar animais</Text>
      <TextInput style={styles.input} placeholder="Digite nome ou raça..." />

      <View style={styles.filters}>
        <TouchableOpacity style={styles.filterButton}><Text style={styles.filterText}>Fêmea</Text></TouchableOpacity>
        <TouchableOpacity style={styles.filterButton}><Text style={styles.filterText}>Macho</Text></TouchableOpacity>
        <TouchableOpacity style={styles.filterButton}><Text style={styles.filterText}>Pequeno</Text></TouchableOpacity>
        <TouchableOpacity style={styles.filterButton}><Text style={styles.filterText}>Médio</Text></TouchableOpacity>
      </View>

      <Text style={styles.subtitle}>Resultados</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: theme.colors.background, flex: 1, padding: theme.spacing(2) },
  title: { fontSize: 24, fontFamily: theme.fonts.bold, color: theme.colors.primary },
  input: {
    borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 10, padding: 10,
    marginVertical: 12, backgroundColor: 'white',
  },
  filters: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  filterButton: {
    backgroundColor: theme.colors.accent, paddingHorizontal: 14,
    paddingVertical: 8, borderRadius: 20,
  },
  filterText: { color: 'white', fontFamily: theme.fonts.bold },
  subtitle: { fontSize: 18, marginTop: 16, fontFamily: theme.fonts.bold, color: theme.colors.secondary },
});
