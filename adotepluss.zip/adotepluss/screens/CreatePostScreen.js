import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import theme from '../styles/theme';

export default function CreatePostScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Criar nova publicação</Text>

      <TextInput placeholder="Nome do animal" style={styles.input} />
      <TextInput placeholder="Raça / Tipo" style={styles.input} />
      <TextInput placeholder="Idade" style={styles.input} />
      <TextInput placeholder="Descrição" multiline style={[styles.input, { height: 100 }]} />

      <TouchableOpacity style={styles.button}><Text style={styles.buttonText}>Publicar</Text></TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background, padding: 20 },
  title: { fontSize: 24, fontFamily: theme.fonts.bold, color: theme.colors.primary, marginBottom: 16 },
  input: {
    borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 10, backgroundColor: 'white',
    padding: 12, marginBottom: 12,
  },
  button: { backgroundColor: theme.colors.secondary, padding: 14, borderRadius: 10, alignItems: 'center' },
  buttonText: { color: 'white', fontFamily: theme.fonts.bold, fontSize: 16 },
});
