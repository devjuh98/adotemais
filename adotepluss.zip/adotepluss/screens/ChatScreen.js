import React from 'react';
import { View, Text, TextInput, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import ChatBubble from '../components/ChatBubble';
import theme from '../styles/theme';

export default function ChatScreen() {
  return (
    <View style={styles.container}>
      <FlatList
        data={[{ id: '1', msg: 'Olá! Está disponível?' }, { id: '2', msg: 'Sim, podemos conversar.' }]}
        renderItem={({ item }) => <ChatBubble message={item.msg} isSender={item.id === '2'} />}
        keyExtractor={item => item.id}
        contentContainerStyle={{ padding: 16 }}
      />

      <View style={styles.inputContainer}>
        <TextInput placeholder="Digite uma mensagem..." style={styles.input} />
        <TouchableOpacity style={styles.button}><Text style={styles.buttonText}>Enviar</Text></TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background },
  inputContainer: { flexDirection: 'row', padding: 10, borderTopWidth: 1, borderColor: '#E5E7EB', backgroundColor: '#fff' },
  input: { flex: 1, borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 20, paddingHorizontal: 14 },
  button: { marginLeft: 8, backgroundColor: theme.colors.primary, borderRadius: 20, paddingHorizontal: 16, justifyContent: 'center' },
  buttonText: { color: 'white', fontFamily: theme.fonts.bold },
});
