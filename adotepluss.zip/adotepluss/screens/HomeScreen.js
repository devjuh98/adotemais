import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import PetCard from '../components/PetCard';
import theme from '../styles/theme';

export default function HomeScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Adote+</Text>
      <Text style={styles.subtitle}>Animais disponíveis para adoção</Text>

      <View style={styles.divider} />

      <View style={styles.feed}>
        <PetCard name="Luna" breed="Vira-lata" age="2 anos" image="https://placekitten.com/300/200" />
        <PetCard name="Thor" breed="Labrador" age="1 ano" image="https://placedog.net/300/200" />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: theme.colors.background, flex: 1, padding: theme.spacing(2) },
  title: { fontSize: 28, fontFamily: theme.fonts.bold, color: theme.colors.primary },
  subtitle: { fontSize: 16, fontFamily: theme.fonts.regular, color: theme.colors.text },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 12 },
  feed: { gap: 16 },
});
