import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
import PetCard from '../components/PetCard';
import theme from '../styles/theme';

export default function ProfileScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image source={{ uri: 'https://i.pravatar.cc/150?img=3' }} style={styles.avatar} />
        <Text style={styles.name}>Maria Oliveira</Text>
        <Text style={styles.bio}>Amante de animais, ajudando a encontrar novos lares 💚</Text>
      </View>

      <View style={styles.divider} />

      <Text style={styles.section}>Meus anúncios</Text>
      <PetCard name="Mel" breed="Golden" age="3 anos" image="https://placedog.net/300/200?id=4" />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background },
  header: { alignItems: 'center', padding: 20 },
  avatar: { width: 100, height: 100, borderRadius: 50 },
  name: { fontSize: 22, fontFamily: theme.fonts.bold, color: theme.colors.primary, marginTop: 10 },
  bio: { fontFamily: theme.fonts.regular, color: theme.colors.text, textAlign: 'center', marginTop: 4 },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 16 },
  section: { fontSize: 18, fontFamily: theme.fonts.bold, color: theme.colors.secondary, marginLeft: 16 },
});
